({
	singleSort: "Single Sort",
	nestedSort: "Nested Sort",
	ascending: "Ascending",
	descending: "Descending",
	sortingState: "${0} - ${1}",
	unsorted: "Do not sort this column",
	indirectSelectionRadio: "Row ${0}, single selection, radio box",
	indirectSelectionCheckBox: "Row ${0}, multiple selection, check box",
	selectAll: "Select all"
})
